# CloudDrop v2

Full owner/admin file-sharing panel.

## Windows
python -m venv .venv
.venv\Scripts\activate
pip install -r requirements.txt
python app.py

Open http://127.0.0.1:5000
Owner panel: http://127.0.0.1:5000/admin

Default owner login:
username: owner
password: admin123

CHANGE THIS PASSWORD immediately.

## VPS
Set:
ADMIN_PASSWORD=your-initial-password
SECRET_KEY=your-long-random-secret
MAX_FILE_MB=512

Then run with a process manager such as systemd and reverse proxy with Caddy/Nginx.

## Included owner controls
Dashboard, file manager, rename/delete/download, users, ban/unban, share-link records,
site settings, maintenance mode, activity logs, storage/disk statistics, password change.
