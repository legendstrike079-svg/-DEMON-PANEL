
import os, uuid, sqlite3, secrets, shutil, mimetypes
from pathlib import Path
from datetime import datetime, timedelta
from functools import wraps
from flask import Flask, render_template, request, redirect, url_for, send_from_directory, abort, flash, session, jsonify
from werkzeug.utils import secure_filename
from werkzeug.security import generate_password_hash, check_password_hash

BASE=Path(__file__).resolve().parent
UPLOADS=BASE/"uploads"
DB=BASE/"clouddrop.db"
UPLOADS.mkdir(exist_ok=True)

app=Flask(__name__)
app.secret_key=os.environ.get("SECRET_KEY", secrets.token_hex(32))
MAX_FILE_MB=int(os.environ.get("MAX_FILE_MB","512"))
DEFAULT_ADMIN=os.environ.get("ADMIN_PASSWORD","admin123")

def db():
    c=sqlite3.connect(DB)
    c.row_factory=sqlite3.Row
    return c

def init_db():
    with db() as c:
        c.executescript("""
        CREATE TABLE IF NOT EXISTS settings(key TEXT PRIMARY KEY,value TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS admins(id INTEGER PRIMARY KEY AUTOINCREMENT,username TEXT UNIQUE NOT NULL,password TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS files(
          id TEXT PRIMARY KEY, original_name TEXT NOT NULL, stored_name TEXT NOT NULL,
          size INTEGER NOT NULL, mime TEXT, uploader TEXT DEFAULT 'guest',
          downloads INTEGER DEFAULT 0, uploaded_at TEXT NOT NULL
        );
        CREATE TABLE IF NOT EXISTS links(
          id TEXT PRIMARY KEY,file_id TEXT NOT NULL,expires_at TEXT,download_limit INTEGER DEFAULT 0,
          password TEXT,enabled INTEGER DEFAULT 1,created_at TEXT NOT NULL
        );
        CREATE TABLE IF NOT EXISTS users(
          id INTEGER PRIMARY KEY AUTOINCREMENT,username TEXT UNIQUE NOT NULL,
          password TEXT NOT NULL,role TEXT DEFAULT 'user',quota INTEGER DEFAULT 5368709120,
          banned INTEGER DEFAULT 0,created_at TEXT NOT NULL
        );
        CREATE TABLE IF NOT EXISTS logs(
          id INTEGER PRIMARY KEY AUTOINCREMENT,action TEXT NOT NULL,details TEXT,
          ip TEXT,created_at TEXT NOT NULL
        );
        """)
        if not c.execute("SELECT 1 FROM settings WHERE key='site_name'").fetchone():
            c.execute("INSERT INTO settings VALUES('site_name','CloudDrop')")
            c.execute("INSERT INTO settings VALUES('tagline','Upload. Share. Download.')")
            c.execute("INSERT INTO settings VALUES('maintenance','0')")
        if not c.execute("SELECT 1 FROM admins").fetchone():
            c.execute("INSERT INTO admins(username,password) VALUES(?,?)",
                      ("owner",generate_password_hash(DEFAULT_ADMIN)))
        c.commit()

def setting(k,default=""):
    with db() as c:
        r=c.execute("SELECT value FROM settings WHERE key=?",(k,)).fetchone()
    return r["value"] if r else default

def log(action,details="",ip=None):
    with db() as c:
        c.execute("INSERT INTO logs(action,details,ip,created_at) VALUES(?,?,?,?)",
                  (action,details,ip or request.remote_addr,datetime.utcnow().isoformat()))
        c.commit()

def admin_required(f):
    @wraps(f)
    def w(*a,**kw):
        if not session.get("admin"): return redirect(url_for("login",next=request.path))
        return f(*a,**kw)
    return w

@app.context_processor
def globals():
    return {"site_name":setting("site_name","CloudDrop"),"tagline":setting("tagline","Upload. Share. Download.")}

@app.before_request
def maintenance_check():
    if request.path.startswith("/admin") or request.path.startswith("/login") or request.path.startswith("/static"):
        return
    if setting("maintenance","0")=="1":
        return "<div style='font:20px system-ui;text-align:center;margin:15vh'>☁️ CloudDrop is under maintenance.<br><small>Please try again later.</small></div>",503

@app.route("/")
def index():
    return render_template("index.html")

@app.route("/upload",methods=["POST"])
def upload():
    f=request.files.get("file")
    if not f or not f.filename:
        flash("Choose a file first."); return redirect(url_for("index"))
    f.stream.seek(0,2); size=f.stream.tell(); f.stream.seek(0)
    if size>MAX_FILE_MB*1024*1024:
        flash(f"Maximum upload size is {MAX_FILE_MB} MB."); return redirect(url_for("index"))
    fid=uuid.uuid4().hex[:12]
    original=secure_filename(f.filename) or "download"
    stored=f"{fid}_{original}"
    f.save(UPLOADS/stored)
    with db() as c:
        c.execute("INSERT INTO files(id,original_name,stored_name,size,mime,uploaded_at) VALUES(?,?,?,?,?,?)",
                  (fid,original,stored,size,f.mimetype or mimetypes.guess_type(original)[0],datetime.utcnow().isoformat()))
        c.commit()
    log("UPLOAD",original)
    return render_template("uploaded.html",file_id=fid,filename=original)

@app.route("/d/<fid>")
def download(fid):
    with db() as c: r=c.execute("SELECT * FROM files WHERE id=?",(fid,)).fetchone()
    if not r: abort(404)
    with db() as c:
        c.execute("UPDATE files SET downloads=downloads+1 WHERE id=?",(fid,)); c.commit()
    log("DOWNLOAD",r["original_name"])
    return send_from_directory(UPLOADS,r["stored_name"],as_attachment=True,download_name=r["original_name"])

@app.route("/view/<fid>")
def view(fid):
    with db() as c:r=c.execute("SELECT * FROM files WHERE id=?",(fid,)).fetchone()
    if not r: abort(404)
    return render_template("view.html",file=r)

@app.route("/login",methods=["GET","POST"])
def login():
    if request.method=="POST":
        u=request.form.get("username","").strip()
        p=request.form.get("password","")
        with db() as c:r=c.execute("SELECT * FROM admins WHERE username=?",(u,)).fetchone()
        if r and check_password_hash(r["password"],p):
            session["admin"]=r["id"]; session["admin_name"]=r["username"]
            log("LOGIN",f"admin={u}")
            return redirect(request.args.get("next") or url_for("admin_dashboard"))
        flash("Invalid owner credentials.")
    return render_template("login.html")

@app.route("/logout")
def logout():
    session.clear(); return redirect(url_for("login"))

@app.route("/admin")
@admin_required
def admin_dashboard():
    with db() as c:
        stats=c.execute("SELECT COUNT(*) files,COALESCE(SUM(size),0) storage,COALESCE(SUM(downloads),0) downloads FROM files").fetchone()
        users=c.execute("SELECT COUNT(*) n FROM users").fetchone()["n"]
        recent=c.execute("SELECT * FROM files ORDER BY uploaded_at DESC LIMIT 10").fetchall()
    return render_template("admin.html",page="dashboard",stats=stats,users=users,recent=recent)

@app.route("/admin/files")
@admin_required
def admin_files():
    q=request.args.get("q","").strip()
    with db() as c:
        rows=c.execute("SELECT * FROM files WHERE original_name LIKE ? ORDER BY uploaded_at DESC",(f"%{q}%",)).fetchall()
    return render_template("admin.html",page="files",files=rows,q=q)

@app.post("/admin/files/delete/<fid>")
@admin_required
def admin_delete(fid):
    with db() as c:r=c.execute("SELECT * FROM files WHERE id=?",(fid,)).fetchone()
    if r:
        (UPLOADS/r["stored_name"]).unlink(missing_ok=True)
        with db() as c:
            c.execute("DELETE FROM files WHERE id=?",(fid,)); c.execute("DELETE FROM links WHERE file_id=?",(fid,)); c.commit()
        log("DELETE_FILE",r["original_name"])
    return redirect(url_for("admin_files"))

@app.post("/admin/files/rename/<fid>")
@admin_required
def admin_rename(fid):
    name=secure_filename(request.form.get("name","").strip())
    if name:
        with db() as c:c.execute("UPDATE files SET original_name=? WHERE id=?",(name,fid));c.commit()
        log("RENAME_FILE",f"{fid} -> {name}")
    return redirect(url_for("admin_files"))

@app.route("/admin/users")
@admin_required
def admin_users():
    with db() as c:rows=c.execute("SELECT * FROM users ORDER BY id DESC").fetchall()
    return render_template("admin.html",page="users",users_list=rows)

@app.post("/admin/users/create")
@admin_required
def create_user():
    u=request.form.get("username","").strip(); p=request.form.get("password","")
    if u and p:
        try:
            with db() as c:c.execute("INSERT INTO users(username,password,created_at) VALUES(?,?,?)",(u,generate_password_hash(p),datetime.utcnow().isoformat()));c.commit()
            log("CREATE_USER",u)
        except sqlite3.IntegrityError: flash("Username already exists.")
    return redirect(url_for("admin_users"))

@app.post("/admin/users/toggle/<int:uid>")
@admin_required
def toggle_user(uid):
    with db() as c:c.execute("UPDATE users SET banned=CASE banned WHEN 0 THEN 1 ELSE 0 END WHERE id=?",(uid,));c.commit()
    log("TOGGLE_USER",str(uid)); return redirect(url_for("admin_users"))

@app.post("/admin/users/delete/<int:uid>")
@admin_required
def delete_user(uid):
    with db() as c:c.execute("DELETE FROM users WHERE id=?",(uid,));c.commit()
    log("DELETE_USER",str(uid)); return redirect(url_for("admin_users"))

@app.route("/admin/links")
@admin_required
def admin_links():
    with db() as c:
        rows=c.execute("""SELECT links.*,files.original_name FROM links JOIN files ON files.id=links.file_id
                          ORDER BY links.created_at DESC""").fetchall()
    return render_template("admin.html",page="links",links=rows)

@app.post("/admin/links/create")
@admin_required
def create_link():
    fid=request.form.get("file_id"); days=int(request.form.get("days") or 0); limit=int(request.form.get("limit") or 0)
    with db() as c:
        if not c.execute("SELECT 1 FROM files WHERE id=?",(fid,)).fetchone(): abort(404)
        lid=secrets.token_urlsafe(9)
        exp=(datetime.utcnow()+timedelta(days=days)).isoformat() if days>0 else None
        c.execute("INSERT INTO links VALUES(?,?,?,?,?,?,?)",(lid,fid,exp,limit,None,1,datetime.utcnow().isoformat()));c.commit()
    log("CREATE_LINK",lid); return redirect(url_for("admin_links"))

@app.post("/admin/links/toggle/<lid>")
@admin_required
def toggle_link(lid):
    with db() as c:c.execute("UPDATE links SET enabled=CASE enabled WHEN 0 THEN 1 ELSE 0 END WHERE id=?",(lid,));c.commit()
    return redirect(url_for("admin_links"))

@app.post("/admin/links/delete/<lid>")
@admin_required
def delete_link(lid):
    with db() as c:c.execute("DELETE FROM links WHERE id=?",(lid,));c.commit()
    return redirect(url_for("admin_links"))

@app.route("/admin/settings",methods=["GET","POST"])
@admin_required
def settings():
    if request.method=="POST":
        for k in ["site_name","tagline","maintenance"]:
            v=request.form.get(k,"0" if k=="maintenance" else "")
            with db() as c:c.execute("INSERT OR REPLACE INTO settings VALUES(?,?)",(k,v));c.commit()
        log("UPDATE_SETTINGS")
        flash("Settings saved.")
    return render_template("admin.html",page="settings",site_name=setting("site_name"),tagline=setting("tagline"),maintenance=setting("maintenance"))

@app.route("/admin/logs")
@admin_required
def logs():
    with db() as c:rows=c.execute("SELECT * FROM logs ORDER BY id DESC LIMIT 250").fetchall()
    return render_template("admin.html",page="logs",logs=rows)

@app.route("/admin/system")
@admin_required
def system():
    total=shutil.disk_usage(BASE)
    used_upload=sum(p.stat().st_size for p in UPLOADS.iterdir() if p.is_file())
    return render_template("admin.html",page="system",disk=total,upload_storage=used_upload,max_mb=MAX_FILE_MB)

@app.post("/admin/change-password")
@admin_required
def change_password():
    p=request.form.get("password","")
    if len(p)<8: flash("Password must be at least 8 characters.")
    else:
        with db() as c:c.execute("UPDATE admins SET password=? WHERE id=?",(generate_password_hash(p),session["admin"]));c.commit()
        flash("Owner password changed.")
        log("CHANGE_ADMIN_PASSWORD")
    return redirect(url_for("system"))

@app.errorhandler(404)
def notfound(_): return render_template("404.html"),404

if __name__=="__main__":
    init_db()
    app.run(host="0.0.0.0",port=int(os.environ.get("PORT","5000")),debug=False)
